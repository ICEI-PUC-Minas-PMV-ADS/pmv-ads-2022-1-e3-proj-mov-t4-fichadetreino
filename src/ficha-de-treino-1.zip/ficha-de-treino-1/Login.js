import React, {useState} from 'react';
import {View, StyleSheet, Text, Pressable, TextInput} from 'react-native';

import Header from './components/Header'
import Button from './components/Button'

const TelaLogin = () => {

  const [nome, setNome] = useState(null);
  const [senha, setSenha] = useState(null);

  const entrar = () => {
    console.log("entrou")
    console.log(nome)
    console.log(senha)
  }


  return (
    <>
    <View style={styles.container}>

      <Header/>
      <Text style={styles.headerText}>Bem Vindo de Volta!</Text>

      <TextInput
      style={styles.textInputLogin}
      label="Usuário"
      placeholder="Login"
      value={nome}
      keyboardType="string"
      onChangeText={text => setNome(text)}
      />
      <TextInput
      style={styles.textInputSenha}
      label="Senha"
      placeholder="senha"
      value={senha}
      onChangeText={text => setSenha(text)}
      secureTextEntry={true}
      />  

      <Button/>
      <Text style = {{marginTop: 0, alignSelf: 'center', textDecorationLine: 'underline'}}>Esqueceu sua senha?</Text>

    </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgraundColor: '#55555',
    alignContent: 'center'
  },
  textInputLogin:{
    height: 48,
    margin: 12,
    marginTop: 100 ,
    borderWidth: 0,
    padding: 15,
    borderRadius: 14 ,
    backgroundColor: '#F7F8F8',
    alignContent: 'center'
  },
  textInputSenha:{
    height: 48,
    margin: 12,
    marginTop: 5,
    borderWidth: 0,
    padding: 15,
    borderRadius: 14 ,
    backgroundColor: '#F7F8F8',
    alignContent: 'center'
  },
  headerText: {
    fontSize: 18,
    lineHeight: 30,
    fontWeight: 'bold',
    letterSpacing: 0.25,
    color: '#6974CF',
    alignSelf: 'center',
    marginTop: 28,
  },
});


export default TelaLogin;