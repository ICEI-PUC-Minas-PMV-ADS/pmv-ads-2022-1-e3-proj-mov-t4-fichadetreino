import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  headerStyle: {
    backgroundColor: '#6974CF',
    position: 'top',
    left: 0,
    right: 0,
    bottom: 0,
  },
});